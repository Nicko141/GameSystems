﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCDialogue : MonoBehaviour
{
    public string characterName;
    public string[] negText, neuText, posText;
    public int approval;
    

    //public Shop myShop;
    public QuestGiver myQuest;
    

    
    
}
